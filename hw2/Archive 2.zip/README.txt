HOMEWORK 2: HOCKEY CLASSES


NAME:  < insert name >
Huiyu Ma


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< insert collaborators / resources >
Teng Liu

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.


ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < insert # hours >
13


DESCRIPTION OF 3RD STATISTIC:
Please be concise! (< 200 words)
What question you are trying to answer with your statistic? 
What data did you need to organize? 
What was interesting or challenging about the implementation of this statistic? 

The question is to identify how significant the “home field advantage”.

The data I need to organize is the win percent for the team when they are in the home field or away home, and I filter the teams which have too few games, the conduction I choose is that the teams should have more than 20 goals.

base on this condition, I find out that there are at least 70% to 80% teams have the Home Field Advantage. which is very significant to prove the hypothesis.



NAME OF FILE WITH SAMPLE OUTPUT FROM 3RD STATISTIC:
Be sure to select (or create) a dataset with interesting results


< ** YOUR STATISTIC GOES HERE ** >
For the team with more than 20 goals
Team Name                 Win%  Home_Win%  Away_Win%  Home_Field_Advantage
Quinnipiac                0.74       0.71       0.80          No
Yale                      0.64       0.74       0.57         Yes
Union                     0.61       0.78       0.48         Yes
Rensselaer                0.57       0.75       0.36         Yes
Dartmouth                 0.54       0.71       0.30         Yes
Brown                     0.54       0.62       0.44         Yes
St._Lawrence              0.54       0.58       0.50         Yes
Cornell                   0.50       0.62       0.39         Yes
Colgate                   0.46       0.68       0.22         Yes
Princeton                 0.38       0.38       0.38          No
Harvard                   0.36       0.47       0.25         Yes
Clarkson                  0.34       0.34       0.33         Yes

The percent of teams with Home Field Advantage 
among the teams with more than 30 goals is: 0.83



< insert filename, file is included with submission >
main.cpp, team.h, team.cpp, player.h, player.cpp


MISC. COMMENTS TO GRADER:  
Optional, please be concise!

