HOMEWORK 5: LINKED TRAIN CARS


NAME:  < insert name >
Huiyu Ma


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< insert collaborators / resources >
Terry Liu

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < insert # hours >
20 hours


DESCRIPTION OF IMPROVED SHIPFREIGHT ALGORITHM FOR EXTRA CREDIT
Aiming for optimal (fastest train speed and fewest number of engines
and trains) for any input.


DESCRIPTION OF IMPROVED SEPARATE ALGORITHM FOR EXTRA CREDIT
Aiming for optimally comfortable trains (smaller values for average
distance to dining and larger values for closest engine to sleeper)
and/or handling cases with > 2 engines.




MISC. COMMENTS TO GRADER:  
Optional, please be concise!


