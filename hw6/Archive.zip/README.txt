HOMEWORK 6: RICOCHET ROBOTS RECURSION


NAME:  < insert name >
Huiyu Ma


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< insert collaborators / resources >
Terry Liu

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < insert # hours >
25



ANALYSIS OF PERFORMANCE OF YOUR ALGORITHM:
(order notation & concise paragraph, < 200 words)

i & j = dimensions of the board
    r = number of robots on the board
    g = number of goals
    w = number of interior walls
    m = maximum total number of moves allowed

O(r^m)


SUMMARY OF PERFORMANCE OF YOUR PROGRAM ON THE PROVIDED PUZZLES:
Correctness & approximate wall clock running time for various command
line arguments.

Approximate longest time:
puzzle1: 0.1s
puzzle2: 0.1s
puzzle3: 16m
puzzle4: 0.1s
puzzle5: 6m
puzzle6: 6m
puzzle7: 1s
puzzle8: 6m



MISC. COMMENTS TO GRADER:  
(optional, please be concise!)

Test 4 and Test 9 can’t come up with a solution on the server, work well on my laptop
